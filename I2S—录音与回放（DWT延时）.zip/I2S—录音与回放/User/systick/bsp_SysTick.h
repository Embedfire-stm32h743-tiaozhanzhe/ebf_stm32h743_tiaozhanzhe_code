#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32h7xx.h"

typedef uint32_t  u32;

extern void SysTick_Init(void);
extern void Delay_us(__IO u32 nTime);
extern void TimingDelay_Decrement(void);
#define Delay_ms(x) HAL_Delay(x)	 //��λms

#endif /* __SYSTICK_H */
