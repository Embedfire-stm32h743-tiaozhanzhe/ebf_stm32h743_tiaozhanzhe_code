#ifndef __MAIN_H
#define __MAIN_H

#include "stm32h7xx_hal.h"

static void SystemClock_Config(void);

#endif /* __MAIN_H */

